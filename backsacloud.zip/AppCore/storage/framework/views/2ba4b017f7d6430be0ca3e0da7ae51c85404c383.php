<header>
    <div class="intro-text col-md-12">
        <div class="intro-lead-in fondotitulo">
            <div class="fondotext">
                Deja tu proyecto  en<br><strong>manos de expertos!</strong>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">

        </div>
    </div>

    <div class="cinta">
        <h2><strong>Somos especialistas</strong> en diseño y desarrollo web</h2>
    </div>
</header><?php /**PATH /opt/lampp/htdocs/paginasOdontologas/AppGestorContenido/resources/views/layouts/website/header.blade.php ENDPATH**/ ?>