<my-header :categories="categories" :subcategories="subCategories" :items_cart="items" :currency="currency" :money="money" :invoice="inovice" :id_cart="idCart"></my-header>

<?php $__env->startPush('js'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/app/header.js')); ?>"></script>
<?php $__env->stopPush(); ?><?php /**PATH /opt/lampp/htdocs/ez/AppGestorContenido/resources/views/layouts/website/header.blade.php ENDPATH**/ ?>