<footer id="footer">
    <div class="footer-top">
        <div class="container">
            <info-contact :storage="folderStorage" :company="company"></info-contact>
        </div>
    </div>
</section>

<div class="container">
    <div class="copyright">
    &copy; Copyright 2019. Dr. Bulla | Diseñado por <a href="https://2Web.us">2Web</a> | Todos los derechos reservados</a>
</div>
</div>
</footer><!-- #footer -->


<a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a><?php /**PATH /opt/lampp/htdocs/AppSistemasIntegrados/AppCore/resources/views/layouts/website/footer.blade.php ENDPATH**/ ?>