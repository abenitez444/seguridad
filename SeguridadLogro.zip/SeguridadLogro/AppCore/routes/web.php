<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['prefix' => '/'], function(){

	// Dashboard
	Route::get('/', 'Admin\DashboardController@index')->name('admin.index');
});

Route::group(['prefix' => 'admin_'], function(){
	Route::get('/', 'Admin\DashboardController@index')->name('admin.dashboard');

	// Auth
	Route::get('/login', 'Admin\Auth\LoginController@showLoginFormAdmin')->name('admin.showLoginFormAdmin');
	Route::post('/login', 'Admin\Auth\LoginController@login')->name('admin.login');

	Route::group(['prefix' => 'users'], function(){
		Route::get('/profile', 'Admin\DashboardController@showProfile')->name('users.showProfile');
		Route::get('/getProfile', 'Admin\DashboardController@getProfile')->name('users.getProfile');
		Route::post('/updateProfile', 'Admin\DashboardController@updateProfile')->name('users.updateProfile');
	});

	Route::get('/shifts/getAllActivated', 'Admin\ShiftsController@getAllActivated');
	Route::get('/clients/getAllWithPagination', 'Admin\ClientsController@getAllWithPagination');
	Route::get('/clients/getEmpty', 'Admin\ClientsController@getEmpty');
	Route::resource('/clients', 'Admin\ClientsController');

	Route::get('/watchmen/getAllWithPagination', 'Admin\WatchmenController@getAllWithPagination');
	Route::get('/watchmen/getAllActivated', 'Admin\WatchmenController@getAllActivated');
	Route::get('/watchmen/getAllFree', 'Admin\WatchmenController@getAllFree');
	Route::resource('/watchmen', 'Admin\WatchmenController');

	Route::post('/assignment', 'Admin\AssignmentController@store')->name('admin.assignment.store');
	Route::delete('/assignment/{id}', 'Admin\AssignmentController@destroy')->name('admin.assignment.destroy');
	Route::get('/assignment', 'Admin\AssignmentController@assignment')->name('admin.assignment');
	Route::get('/assignment/form', 'Admin\AssignmentController@assignment_form')->name('admin.assignment.create');
	Route::get('/assignment/getAllWithPagination', 'Admin\AssignmentController@getAllWithPagination');
});

Auth::routes();

Route::get('/home', 'Admin\DashboardController@index')->name('home');
