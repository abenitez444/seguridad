<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class Assignment extends Model
{
    protected $table = 'assignment';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'clients_id',
        'date_ini',
    ];

    public function client()
    {
        return $this->belongsTo(Clients::class, 'clients_id');
    }

    public function watchmen()
    {
        return $this->belongsToMany(Watchmen::class, 'assignment_as_watchmen', 'assignment_id', 'watchmen_id')->withPivot('start');
    }
}
