<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class Watchmen extends Model
{
    protected $table = 'watchmen';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'dni',
        'email',
        'phone',
        'address',
        'is_active',
    ];

    public function assignment()
    {
        return $this->belongsToMany(Assignment::class, 'assignment_as_watchmen', 'watchmen_id', 'assignment_id');
    }
}
