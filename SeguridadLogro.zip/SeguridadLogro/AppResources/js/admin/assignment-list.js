new Vue({
	el: '#app-main',
	data: {
		loading: true,
		sending: false,
		action: 'save',
		assignment: {
			type: '',
			clients_id: '',
			client: {},
			list_watchmen: [],
			date_ini: '1990-01-30',
		},
		pagination: {
			'total': 0,
			'current_page': 1,
			'per_page': 100,
			'last_page': 0,
			'from': 0,
			'to': 0 
		},
		offset: 3,
		columns: [
            // {label: 'Imagén', field: 'image'},
            {label: 'ID', field: 'id'},
            {label: 'Puesto', field: 'client.name'},
            {label: 'Nº de Servicios', field: 'client.num_services'},
            {label: 'Programación', field: 'client.shift.name'},
            {label: 'Fecha de inicio', field: 'date_ini'},
            {label: '', field: ''},
            // {label: 'address', representedAs: ({address, city, state}) => `${address}<br />${city}, ${state}`, interpolate: true}
        ],
        rows: [],
        filter: '',
        per_page: 100,
        calendar: '',
	},
	created() {
		this.loading = true;
	},
	methods: {
		makePagination: function(response){
			this.pagination = {
				'total': response.total,
				'current_page': response.current_page,
				'per_page': response.per_page,
				'last_page': response.last_page,
				'from': response.from,
				'to': response.to
			}
		},
		changePerPage()
		{
			this.pagination.per_page = this.per_page;
			this.getAllWithPagination();
		},
		changePage(page)
		{
			if (this.pagination.current_page == page) {
				return false;
			}

			this.pagination.current_page = page;
			this.getAllWithPagination();
		},
		showErrorMessage: function(messages = []){
        	this.errorMessage = '';
        	for (var i = 0; i < messages.length; i++) {
        		this.errorMessage += '<b>' + (i + 1) + '. ' + messages[i] + '</b><br/>';
        	}
        	Swal.fire({
                title: '¡Error!',
                html: this.errorMessage,
                icon: 'error',
            });
        },
		view(element) {
			this.action = 'update';
			this.client = element;			
			// $("#modal-form").modal('show');
		},
		getAllWithPagination(){
			var url = '/admin_/assignment/getAllWithPagination/';
			url += '?page='+this.pagination.current_page+'&per_page='+this.pagination.per_page;
			this.loading = true;
			axios.get(url).then(response => {
				console.log(response.data);
				this.rows = response.data.data;
				this.makePagination(response.data);
				this.loading = false;
			}).catch(error => {
				this.loading = false;
				console.log(error);
			});
		},
		removeItem(element) {
			var url = '/admin_/assignment/'+element.id;
			Swal.fire({
        		title: 'Está seguro de eliminar el dato?',
        		html: "Si acepta eliminar no abrá vuelta atras, el dato será eliminado de forma permanente<br/>\
        				al igual que todos los datos relacionado al el.",
        		icon: 'question',
        		showCancelButton: true,
        		confirmButtonColor: '#3085d6',
        		cancelButtonColor: '#d33',
        		confirmButtonText: 'Si, eliminar!'
        	}).then((result) => {
        		if (result.value) {
        			this.loading = true;
					this.sending = true;
        			axios.delete(url).then(response => {
        				this.sending = false;
						this.loading = false;
						for (var i = 0; i < this.rows.length; i++) {
							var r = this.rows[i];
							if (r.id == element.id) {
								this.rows.splice(i, 1);
								break;
							}
						}
						Swal.fire({
		                  position: 'center',
		                  icon: 'success',
		                  title: 'Se ha eliminado con éxito',
		                  showConfirmButton: false,
		                  timer: 1300
		                });
        			}).catch(error => {
        				console.log(error);
						this.sending = false;
						this.loading = false;
						if (typeof error.response.data.errors !== 'undefined') {                        
		                    this.errors = $.map(error.response.data.errors, function(value, index) {
		                        var err = '';
		                        $.map(value, function(v, i){
		                            err = v;
		                        });
		                            //this.errors[index].push() = [value];
		                            return [err];
		                        });
		                    this.showErrorMessage(this.errors);
		                } else {
		                    swal("¡Error!", 'Se ha producido un error', "error");
		                }
        			});     			
        		}
        	});
		},
		eventDay(vigilant, start_date, day)
		{
			return {
					title          : '(D) '+vigilant.name,
					start          : new Date(start_date.getFullYear(), start_date.getMonth(), start_date.getDate()+day),
					allDay         : true,
					backgroundColor: '#17a2b8',
					borderColor    : '#17a2b8'
			}
		},
		eventNight(vigilant, start_date, day)
		{
			return {
					title          : '(N) '+vigilant.name,
					start          : new Date(start_date.getFullYear(), start_date.getMonth(), start_date.getDate()+day),
					allDay         : true,
					backgroundColor: '#6c757d',
					borderColor    : '#6c757d'
			}
		},
		eventX(vigilant, start_date, day)
		{
			return {
					title          : '(X) '+vigilant.name,
					start          : new Date(start_date.getFullYear(), start_date.getMonth(), start_date.getDate()+day),
					allDay         : true,
					backgroundColor: '#28a745',
					borderColor    : '#28a745'
			}
		},
		viewCalendar(element)
		{
			var date = new Date()
		    var d    = date.getDate(),
		        m    = date.getMonth(),
		        y    = date.getFullYear()

		    var start = element.date_ini;
		    start = start.split('-');
		    var start_date = new Date(start[0], start[1]-1, start[2]);

		    if (start_date.getMonth() < 10) {
		    	var end = (start_date.getFullYear()+1)+'-0'+(start_date.getMonth())+'-'+start_date.getDate();
		    } else {
		    	var end = (start_date.getFullYear()+1)+'-'+(start_date.getMonth())+'-'+start_date.getDate();
		    }
		    end = end.split('-');
		    var end_date =  new Date(end[0],end[1],end[2]);
		    var list_event = [];

	    	for (var j = 0; j < element.watchmen.length; j++) {
	    		var vigilant = element.watchmen[j];
	    		console.log(vigilant);
	    		var programation = [];
				var cant_d = 0;
				var cant_n = 0;
				var cant_x = 0;
				var cant_total = 0;
				if (element.client.shift.name == '2X2') {
					if (vigilant.pivot.start == 'D') {
						for (var i = 0; i < 365; i++) {
							if (cant_d < 2) {
								programation.push('D');
								cant_d++;
								var event = this.eventDay(vigilant, start_date, i);
							} else if (cant_d == 2 && cant_n < 2) {
								programation.push('N');
								cant_n++;
								var event = this.eventNight(vigilant, start_date, i);
							} else if (cant_d == 2 && cant_n == 2 && cant_x < 2) {
								programation.push('X');
								cant_x++;
								var event = this.eventX(vigilant, start_date, i);
							}
							cant_total++;

							if (cant_total == 6) {
								cant_d = 0;
								cant_n = 0;
								cant_x = 0;
								cant_total = 0;
							}
							list_event.push(event);
						}
					}
					if (vigilant.pivot.start == 'N') {
						for (var i = 0; i < 365; i++) {
							if (cant_n < 2) {
								programation.push('N');
								cant_n++;
								var event = this.eventNight(vigilant, start_date, i);
							} else if (cant_n == 2 && cant_x < 2) {
								programation.push('X');
								cant_x++;
								var event = this.eventX(vigilant, start_date, i);
							} else if (cant_n == 2 && cant_x == 2 && cant_d < 2) {
								programation.push('D');
								cant_d++;
								var event = this.eventDay(vigilant, start_date, i);
							}
							cant_total++;
							if (cant_total == 6) {
								cant_d = 0;
								cant_n = 0;
								cant_x = 0;
								cant_total = 0;
							}
							list_event.push(event);						
						}
					}
					if (vigilant.pivot.start == 'X') {
						for (var i = 0; i < 365; i++) {
							if (cant_x < 2) {
								programation.push('X');
								cant_x++;
								var event = this.eventX(vigilant, start_date, i);
							} else if (cant_x == 2 && cant_d < 2) {
								programation.push('D');
								cant_d++;
								var event = this.eventDay(vigilant, start_date, i);
							} else if (cant_d == 2 && cant_x == 2 && cant_n < 2) {
								programation.push('N');
								cant_n++;
								var event = this.eventNight(vigilant, start_date, i);
							}
							cant_total++;
							if (cant_total == 6) {
								cant_d = 0;
								cant_n = 0;
								cant_x = 0;
								cant_total = 0;
							}
							list_event.push(event);
						}
					}
				} else if(element.client.shift.name == '4X2 Día'){
					if (vigilant.pivot.start == 'D') {
						for (var i = 0; i < 365; i++) {
							if (cant_d < 4) {
								programation.push('D');
								cant_d++;
								var event = this.eventDay(vigilant, start_date, i);
							} else if (cant_d == 4 && cant_n < 2) {
								programation.push('N');
								cant_n++;
								var event = this.eventNight(vigilant, start_date, i);
							} else if (cant_d == 4 && cant_n == 2 && cant_x < 2) {
								programation.push('X');
								cant_x++;
								var event = this.eventX(vigilant, start_date, i);
							}
							cant_total++;

							if (cant_total == 8) {
								cant_d = 0;
								cant_n = 0;
								cant_x = 0;
								cant_total = 0;
							}
							list_event.push(event);					
						}
					}
					if (vigilant.pivot.start == 'N') {
						for (var i = 0; i < 365; i++) {
							if (cant_n < 2) {
								programation.push('N');
								cant_n++;
								var event = this.eventNight(vigilant, start_date, i);
							} else if (cant_n == 2 && cant_x < 2) {
								programation.push('X');
								cant_x++;
								var event = this.eventX(vigilant, start_date, i);
							} else if (cant_n == 2 && cant_x == 2 && cant_d < 4) {
								programation.push('D');
								cant_d++;
								var event = this.eventDay(vigilant, start_date, i);
							}
							cant_total++;
							if (cant_total == 8) {
								cant_d = 0;
								cant_n = 0;
								cant_x = 0;
								cant_total = 0;
							}	
							list_event.push(event);					
						}
					}
					if (vigilant.pivot.start == 'X') {
						for (var i = 0; i < 365; i++) {
							if (cant_x < 2) {
								programation.push('X');
								cant_x++;
								var event = this.eventX(vigilant, start_date, i);
							} else if (cant_x == 2 && cant_d < 4) {
								programation.push('D');
								cant_d++;
								var event = this.eventDay(vigilant, start_date, i);
							} else if (cant_d == 4 && cant_x == 2 && cant_n < 2) {
								programation.push('N');
								cant_n++;
								var event = this.eventNight(vigilant, start_date, i);
							}
							cant_total++;
							if (cant_total == 8) {
								cant_d = 0;
								cant_n = 0;
								cant_x = 0;
								cant_total = 0;
							}
							list_event.push(event);
						}
					}
				} else if(element.client.shift.name == '4X2 Noche'){
					if (vigilant.pivot.start == 'D') {
						for (var i = 0; i < 365; i++) {
							if (cant_d < 2) {
								programation.push('D');
								cant_d++;
								var event = this.eventDay(vigilant, start_date, i);
							} else if (cant_d == 2 && cant_n < 4) {
								programation.push('N');
								cant_n++;
								var event = this.eventNight(vigilant, start_date, i);
							} else if (cant_d == 2 && cant_n == 4 && cant_x < 2) {
								programation.push('X');
								cant_x++;
								var event = this.eventX(vigilant, start_date, i);
							}
							cant_total++;

							if (cant_total == 8) {
								cant_d = 0;
								cant_n = 0;
								cant_x = 0;
								cant_total = 0;
							}
							list_event.push(event)			
						}
					}
					if (vigilant.pivot.start == 'N') {
						for (var i = 0; i < 365; i++) {
							if (cant_n < 4) {
								programation.push('N');
								cant_n++;
								var event = this.eventNight(vigilant, start_date, i);
							} else if (cant_n == 4 && cant_x < 2) {
								programation.push('X');
								cant_x++;
								var event = this.eventX(vigilant, start_date, i);
							} else if (cant_n == 4 && cant_x == 2 && cant_d < 2) {
								programation.push('D');
								cant_d++;
								var event = this.eventDay(vigilant, start_date, i);
							}
							cant_total++;
							if (cant_total == 8) {
								cant_d = 0;
								cant_n = 0;
								cant_x = 0;
								cant_total = 0;
							}
							list_event.push(event);
						}
					}
					if (vigilant.pivot.start == 'X') {
						for (var i = 0; i < 365; i++) {
							if (cant_x < 2) {
								programation.push('X');
								cant_x++;
								var event = this.eventX(vigilant, start_date, i);
							} else if (cant_x == 2 && cant_d < 2) {
								programation.push('D');
								cant_d++;
								var event = this.eventDay(vigilant, start_date, i);
							} else if (cant_d == 2 && cant_x == 2 && cant_n < 4) {
								programation.push('N');
								cant_n++;
								var event = this.eventNight(vigilant, start_date, i);
							}
							cant_total++;
							if (cant_total == 8) {
								cant_d = 0;
								cant_n = 0;
								cant_x = 0;
								cant_total = 0;
							}
							list_event.push(event);
						}
					}
				}else {
					if (vigilant.pivot.start == 'N') {
						for (var i = 0; i < 365; i++) {
							if (cant_n < 5) {
								programation.push('N');
								cant_n++;
								var event = this.eventNight(vigilant, start_date, i);
							} else if (cant_n == 5 && cant_x < 2) {
								programation.push('X');
								cant_x++;
								var event = this.eventX(vigilant, start_date, i);
							}
							cant_total++;
							if (cant_total == 7) {
								cant_d = 0;
								cant_n = 0;
								cant_x = 0;
								cant_total = 0;
							}
							list_event.push(event);					
						}
					}
					if (vigilant.pivot.start == 'X') {
						for (var i = 0; i < 365; i++) {
							if (cant_x < 2) {
								programation.push('X');
								cant_x++;
								var event = this.eventX(vigilant, start_date, i);
							} else if (cant_x == 2 && cant_n < 5) {
								programation.push('N');
								cant_n++;
								var event = this.eventNight(vigilant, start_date, i);
							}
							cant_total++;
							if (cant_total == 7) {
								cant_d = 0;
								cant_n = 0;
								cant_x = 0;
								cant_total = 0;
							}
							list_event.push(event);
						}
					}
				}
	    	}

		    console.log(list_event);
		    console.log(element.date_ini);
		    console.log(start_date);
		    console.log(end);
		    console.log(end_date);

		    var Calendar = FullCalendar.Calendar;
		    var Draggable = FullCalendarInteraction.Draggable;
		    var containerEl = document.getElementById('external-events');
		    var checkbox = document.getElementById('drop-remove');
		    var calendarEl = document.getElementById('calendar');
		    if (this.calendar != '') {
		    	this.calendar.destroy();
		    }
		    this.calendar = new Calendar(calendarEl, {
	      		plugins: [ 'bootstrap', 'interaction', 'dayGrid', 'timeGrid' ],
	      		header    : {
	        		left  : 'prev,next today',
	        		center: 'title',
	        		right : 'dayGridMonth'
	     		},
	      		//Random default events
			    events    : list_event,
	      		editable  : false,
	      		droppable : true, // this allows things to be dropped onto the calendar !!!
	      		drop      : function(info) {
	        		// is the "remove after drop" checkbox checked?
	        		if (checkbox.checked) {
	          			// if so, remove the element from the "Draggable Events" list
	          			info.draggedEl.parentNode.removeChild(info.draggedEl);
	        		}
	      		}    
	    	});

	    	this.calendar.render();
	    	setTimeout(function(){
	    		$("button.fc-dayGridMonth-button").trigger('click');
	    	},500)
		}
	},
	computed: {
    	isActived: function() {
    		return this.pagination.current_page;
    	},

    	pagesNumber: function() {
    		if (!this.pagination.to) {
    			return [1];
    		}

    		var from = this.pagination.current_page - this.offset;
    		if (from < 1) {
    			from = 1;
    		}

    		var to = from + (this.offset * 2);
    		if (to > this.pagination.last_page) {
    			to = this.pagination.last_page;
    		}

    		var pagesArray = [];
    		while(from <= to) {
    			pagesArray.push(from);
    			from++;
    		}

    		return pagesArray;
    	}
    },
	mounted(){
        this.getAllWithPagination();
	}
});