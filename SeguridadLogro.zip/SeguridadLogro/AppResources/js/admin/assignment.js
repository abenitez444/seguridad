new Vue({
	el: '#app-main',
	data: {
		loading: false,
		action: 'save',
		start: false,
		assignment: {
			type: '',
			clients_id: '',
			list_watchmen: [],
			date_ini: '1990-01-30',
		},
		clients: [],
		watchmen: [],
		vigilant_selected: '',
		client_selected: {shift:{name:''}},
		start_vigilant: 'D',
		date_min: '1990-01-30',
		days_preview: [],
	},
	created() {
		this.getFreeWatchers();
		var date = new Date();
		
		if (date.getMonth() < 10) {
			var now = date.getFullYear()+'-0'+(date.getMonth()+1)+'-'+date.getDate();
		} else {
			var now = date.getFullYear()+'-'+(date.getMonth()+1)+'-'+date.getDate();
		}
		this.assignment.date_ini = now;
		this.date_min = now;
		for (var i = 1; i < 32; i++) {
			this.days_preview.push(i);
		}
	},
	methods: {
		getFreeWatchers()
		{
			axios.get('/admin_/watchmen/getAllFree').then(response => {
				this.watchmen = response.data;
			});
		},
		changeType()
		{
			this.start = false;
			if (this.assignment.type == 'nuevo') {
				this.getEmptyClients();
			}
		},
		getEmptyClients()
		{
			this.clients = [];
			axios.get('/admin_/clients/getEmpty').then(response => {
				console.log(response.data);
				this.clients = response.data;
			});
		},
		startassignment()
		{
			this.start = true;
			this.assignment.list_watchmen = [];
			// this.setClienteSelected();
		},
		setClienteSelected()
		{
			if (this.assignment.clients_id == '') {
				return this.client_selected = {shift:{name:''}};
			}
			for (var i = 0; i < this.clients.length; i++) {
				var c = this.clients[i];
				if (c.id == this.assignment.clients_id) {
					this.client_selected = c;
				}
			}
			this.list_watchmen = [];
			this.start = false;
		},
		addVigilant()
		{
			var selected = {id: ''};
			var in_list = false;
			for (var i = 0; i < this.watchmen.length; i++) {
				var w = this.watchmen[i];
				if (this.vigilant_selected == w.id) {
					selected = w;
					break;
				}
			}

			for (var i = 0; i < this.assignment.list_watchmen.length; i++) {
				var w = this.assignment.list_watchmen[i];
				if (w.id == selected.id) {
					in_list = true;
					break;
				}
			}
			this.vigilant_selected = '';
			if (in_list) {
				return false;
			}

			selected.start = this.start_vigilant;
			return this.assignment.list_watchmen.push(selected);
		},
		save()
		{
			if (this.assignment.list_watchmen.length != this.client_selected.num_services*3) {
				Swal.fire({
                    title: '¡Error!',
                    text: 'El puesto selecionado debe tener un total de '+this.client_selected.num_services*3+' vigilante\
                    , ya que posee un número de '+this.client_selected.num_services+' servicios',
                    icon: 'error',
                });
				return false;
			}
			this.loading = true;
			axios.post('/admin_/assignment', this.assignment).then(response => {
				console.log(response.data);
				Swal.fire({
                  position: 'center',
                  icon: 'success',
                  title: 'Se ha guardado con éxito',
                  showConfirmButton: false,
                  timer: 1300
                });
				this.loading = false;
				// this.init();
				location.href = APP_URL + '/admin_/assignment';
			}).catch(error => {
				console.log(error.response.data);
				this.loading = false;
			})
		},
		init()
		{
			this.loading = false;
			this.action = 'save';
			this.start = false;
			this.assignment = {
				type: '',
				clients_id: '',
				list_watchmen: [],
			};
			this.clients = [];
			this.watchmen = [];
			this.vigilant_selected = '';
			this.client_selected = {shift:{name:''}};
		},
		programationVigilant(vigilant)
		{
			var programation = [];
			var cant_d = 0;
			var cant_n = 0;
			var cant_x = 0;
			var cant_total = 0;
			if (this.client_selected.shift.name == '2X2') {
				if (vigilant.start == 'D') {
					for (var i = 1; i < 32; i++) {
						if (cant_d < 2) {
							programation.push('D');
							cant_d++;
						} else if (cant_d == 2 && cant_n < 2) {
							programation.push('N');
							cant_n++;
						} else if (cant_d == 2 && cant_n == 2 && cant_x < 2) {
							programation.push('X');
							cant_x++;
						}
						cant_total++;

						if (cant_total == 6) {
							cant_d = 0;
							cant_n = 0;
							cant_x = 0;
							cant_total = 0;
						}					
					}
				}
				if (vigilant.start == 'N') {
					for (var i = 1; i < 32; i++) {
						if (cant_n < 2) {
							programation.push('N');
							cant_n++;
						} else if (cant_n == 2 && cant_x < 2) {
							programation.push('X');
							cant_x++;
						} else if (cant_n == 2 && cant_x == 2 && cant_d < 2) {
							programation.push('D');
							cant_d++;
						}
						cant_total++;
						if (cant_total == 6) {
							cant_d = 0;
							cant_n = 0;
							cant_x = 0;
							cant_total = 0;
						}						
					}
				}
				if (vigilant.start == 'X') {
					for (var i = 1; i < 32; i++) {
						if (cant_x < 2) {
							programation.push('X');
							cant_x++;
						} else if (cant_x == 2 && cant_d < 2) {
							programation.push('D');
							cant_d++;
						} else if (cant_d == 2 && cant_x == 2 && cant_n < 2) {
							programation.push('N');
							cant_n++;
						}
						cant_total++;
						if (cant_total == 6) {
							cant_d = 0;
							cant_n = 0;
							cant_x = 0;
							cant_total = 0;
						}
					}
				}
			} else if(this.client_selected.shift.name == '4X2 Día'){
				if (vigilant.start == 'D') {
					for (var i = 1; i < 32; i++) {
						if (cant_d < 4) {
							programation.push('D');
							cant_d++;
						} else if (cant_d == 4 && cant_n < 2) {
							programation.push('N');
							cant_n++;
						} else if (cant_d == 4 && cant_n == 2 && cant_x < 2) {
							programation.push('X');
							cant_x++;
						}
						cant_total++;

						if (cant_total == 8) {
							cant_d = 0;
							cant_n = 0;
							cant_x = 0;
							cant_total = 0;
						}					
					}
				}
				if (vigilant.start == 'N') {
					for (var i = 1; i < 32; i++) {
						if (cant_n < 2) {
							programation.push('N');
							cant_n++;
						} else if (cant_n == 2 && cant_x < 2) {
							programation.push('X');
							cant_x++;
						} else if (cant_n == 2 && cant_x == 2 && cant_d < 4) {
							programation.push('D');
							cant_d++;
						}
						cant_total++;
						if (cant_total == 8) {
							cant_d = 0;
							cant_n = 0;
							cant_x = 0;
							cant_total = 0;
						}						
					}
				}
				if (vigilant.start == 'X') {
					for (var i = 1; i < 32; i++) {
						if (cant_x < 2) {
							programation.push('X');
							cant_x++;
						} else if (cant_x == 2 && cant_d < 4) {
							programation.push('D');
							cant_d++;
						} else if (cant_d == 4 && cant_x == 2 && cant_n < 2) {
							programation.push('N');
							cant_n++;
						}
						cant_total++;
						if (cant_total == 8) {
							cant_d = 0;
							cant_n = 0;
							cant_x = 0;
							cant_total = 0;
						}
					}
				}
			} else if(this.client_selected.shift.name == '4X2 Noche'){
				if (vigilant.start == 'D') {
					for (var i = 1; i < 32; i++) {
						if (cant_d < 2) {
							programation.push('D');
							cant_d++;
						} else if (cant_d == 2 && cant_n < 4) {
							programation.push('N');
							cant_n++;
						} else if (cant_d == 2 && cant_n == 4 && cant_x < 2) {
							programation.push('X');
							cant_x++;
						}
						cant_total++;

						if (cant_total == 8) {
							cant_d = 0;
							cant_n = 0;
							cant_x = 0;
							cant_total = 0;
						}					
					}
				}
				if (vigilant.start == 'N') {
					for (var i = 1; i < 32; i++) {
						if (cant_n < 4) {
							programation.push('N');
							cant_n++;
						} else if (cant_n == 4 && cant_x < 2) {
							programation.push('X');
							cant_x++;
						} else if (cant_n == 4 && cant_x == 2 && cant_d < 2) {
							programation.push('D');
							cant_d++;
						}
						cant_total++;
						if (cant_total == 8) {
							cant_d = 0;
							cant_n = 0;
							cant_x = 0;
							cant_total = 0;
						}						
					}
				}
				if (vigilant.start == 'X') {
					for (var i = 1; i < 32; i++) {
						if (cant_x < 2) {
							programation.push('X');
							cant_x++;
						} else if (cant_x == 2 && cant_d < 2) {
							programation.push('D');
							cant_d++;
						} else if (cant_d == 2 && cant_x == 2 && cant_n < 4) {
							programation.push('N');
							cant_n++;
						}
						cant_total++;
						if (cant_total == 8) {
							cant_d = 0;
							cant_n = 0;
							cant_x = 0;
							cant_total = 0;
						}
					}
				}
			}else {
				if (vigilant.start == 'D') {
					for (var i = 1; i < 32; i++) {
						if (cant_n < 5) {
							programation.push('N');
							cant_n++;
						} else if (cant_n == 5 && cant_x < 2) {
							programation.push('X');
							cant_x++;
						}
						cant_total++;

						if (cant_total == 7) {
							cant_d = 0;
							cant_n = 0;
							cant_x = 0;
							cant_total = 0;
						}					
					}
				}
				if (vigilant.start == 'N') {
					for (var i = 1; i < 32; i++) {
						if (cant_n < 5) {
							programation.push('N');
							cant_n++;
						} else if (cant_n == 5 && cant_x < 2) {
							programation.push('X');
							cant_x++;
						}
						cant_total++;
						if (cant_total == 7) {
							cant_d = 0;
							cant_n = 0;
							cant_x = 0;
							cant_total = 0;
						}						
					}
				}
				if (vigilant.start == 'X') {
					for (var i = 1; i < 32; i++) {
						if (cant_x < 2) {
							programation.push('X');
							cant_x++;
						} else if (cant_x == 2 && cant_n < 5) {
							programation.push('N');
							cant_n++;
						}
						cant_total++;
						if (cant_total == 7) {
							cant_d = 0;
							cant_n = 0;
							cant_x = 0;
							cant_total = 0;
						}
					}
				}
			}

			return programation;
		},
		inListSelected(vigilant)
		{
			var inlist = false;
			for (var i = 0; i < this.assignment.list_watchmen.length; i++) {
				var w = this.assignment.list_watchmen[i];
				if (w.id == vigilant.id) {
					inlist = true;
					break;
				}
			}
			return inlist;
		}
	},
	computed: {
		clienteCompleted()
		{
			if (this.assignment.list_watchmen.length == this.client_selected.num_services*3) {
				return true;
			} else {
				return false;
			}
		},
    },
	mounted(){
	}
});